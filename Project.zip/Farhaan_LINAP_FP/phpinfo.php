<?php
// show all information, defaults to INFO_ALL
phpinfo();
?>
